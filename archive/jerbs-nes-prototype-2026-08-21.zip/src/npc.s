; ------------------------------------------------------------------------
; npc.s -- NPC sprite tile.
;
; A separate file (rather than appending to chr.s) so this tile's index
; doesn't depend on ever having to renumber chr.s's or font.s's tiles --
; as long as this is linked after both, it lands at
; NPC_TILE_BASE = FONT_TILE_BASE + FONT_GLYPH_COUNT (see main.c).
;
; A simple standing-figure silhouette (head/shoulders/legs) rather than
; a recolored copy of the player's solid-block tile, so an NPC reads as
; "a person" at a glance instead of "a different-colored player". Same
; solid-color-index-1 encoding as the player tile (plane0 = shape,
; plane1 = 0) -- the sprite palette loaded for it is what makes it end
; up a different color than the player despite sharing color index 1.
; ------------------------------------------------------------------------

.segment "CHARS"

.byte %00111000   ; ..XXX...  head
.byte %00111000   ; ..XXX...  head
.byte %01111100   ; .XXXXX..  shoulders
.byte %01111100   ; .XXXXX..  body
.byte %01111100   ; .XXXXX..  body
.byte %01111100   ; .XXXXX..  body
.byte %01000100   ; .X...X..  legs apart
.byte %01000100   ; .X...X..  legs apart
.repeat 8
        .byte $00
.endrepeat
