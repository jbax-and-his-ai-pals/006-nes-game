; ------------------------------------------------------------------------
; chr.s -- CHR-ROM pattern data (the game's "graphics")
;
; The NES stores tile graphics as 2 bits per pixel, split into two
; bit-planes of 8 bytes each (one byte per row of the 8x8 tile).
; The final color index for a pixel is (plane1_bit << 1) | plane0_bit.
;
; This file defines six tiles. Tiles 0/2/3 are reused across every
; room/biome -- only the loaded palette changes what colors they end up
; as (grass green vs. sand tan, etc.), which is how "floor" and "path"
; get a different look per biome without needing separate CHR data for
; each. Obstacles get a distinct shape per biome (tile 2 for the meadow's
; tree line, tile 4 for the desert's rocks) since a recolored circle
; wouldn't read as a different kind of thing the way a different
; silhouette does.
;
;   tile 0 - floor: mostly transparent (background palette entry 0, the
;            "backdrop" color) with a few index-1 pixels for texture
;   tile 1 - the player: a small humanoid silhouette (cap/face/body/feet)
;            using 3 sprite-palette colors plus transparency, rather than
;            a solid block -- a single flat color washed out against
;            some biomes' path/backdrop tiles (red against the desert's
;            dark worn trail, especially), where a plain silhouette with
;            the same color reads as "part of the ground." An outline
;            color (index 3) rings the whole shape so it keeps a visible
;            edge against almost any floor color, not just the ones the
;            body/face colors happen to contrast with.
;   tile 2 - mostly-solid color index 2, with a few index-0 "gaps" for
;            texture; the meadow's tree-line border obstacle. Kept mostly
;            solid (unlike tile 0's texture, which is mostly empty) so
;            adjacent copies connect into a continuous hedge instead of
;            reading as separate round bushes with gaps between them.
;   tile 3 - solid color index 3; the path connecting a room's exits
;   tile 4 - a rounded-trapezoid boulder in color index 2; the desert's
;            border obstacle. Same "mostly solid so it connects
;            edge-to-edge" idea as tile 2, different silhouette.
;   tile 5 - the left half of a peaked roof, color index 2: a diagonal
;            rising left-to-right, empty ("sky") above it. Paired with
;            house.s's mirrored right half so two side-by-side copies
;            meet in the middle as one roof peak instead of two separate
;            triangles -- see house.s for why the town's houses need
;            more than one repeated tile the way every other room's
;            obstacle does.
; ------------------------------------------------------------------------

.segment "CHARS"

; --- Tile 0: grass floor (mostly backdrop, with a little texture) ---
.byte $00, $00, $20, $04, $00, $00, $10, $00    ; bit-plane 0
.byte $00, $00, $00, $00, $00, $00, $00, $00    ; bit-plane 1

; --- Tile 1: player -- outline (index 3, white) around a face (index 2,
; orange) and body (index 1, red): cap/headband, face, shoulder trim,
; torso, leg trim, feet. Rows 1-2 and 4-5 are pairs (face, then body) so
; the shape reads as head-over-body at a glance despite being one tile. ---
.byte $7E, $81, $81, $7E, $FF, $FF, $7E, $3C    ; bit-plane 0
.byte $7E, $FF, $FF, $42, $81, $81, $42, $3C    ; bit-plane 1

; --- Tile 2: tree line (color index 2 -> plane0 clear, plane1 set,
; except a few pixels dropped to index 0 for a leafy texture) ---
.byte $00, $00, $00, $00, $00, $00, $00, $00    ; bit-plane 0
.byte $FF, $DF, $FF, $FB, $FF, $BF, $F7, $FF    ; bit-plane 1

; --- Tile 3: path (solid color index 3 -> both planes set) ---
.repeat 8
        .byte $FF
.endrepeat
.repeat 8
        .byte $FF
.endrepeat

; --- Tile 4: boulder (color index 2 -> plane0 clear, plane1 set) ---
.byte $00, $00, $00, $00, $00, $00, $00, $00    ; bit-plane 0
.byte $7C, $FE, $FF, $FF, $FF, $FF, $7E, $3C    ; bit-plane 1

; --- Tile 5: roof, left half (color index 2 -> plane0 clear, plane1 set) ---
.byte $00, $00, $00, $00, $00, $00, $00, $00    ; bit-plane 0
.byte $00, $01, $03, $07, $0F, $1F, $3F, $7F    ; bit-plane 1
