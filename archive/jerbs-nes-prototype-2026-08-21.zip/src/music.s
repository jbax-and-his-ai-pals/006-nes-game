;
; music.s -- a compact, NMI-clocked title theme.
;
; The state is private to this module and the NMI never calls C. This keeps
; the 60 Hz song clock independent of room rendering and game-loop load.
;

        .export _music_start, _music_sfx_swing, _music_sfx_pickup
        .export _music_sfx_dialogue, _music_sfx_hit, _music_sfx_hurt
        .export _music_sfx_door, music_nmi_tick

        .include "nes.inc"

MUSIC_STEPS = 16

.segment "RODATA"
; A warm, looping title phrase: pulse carries the tune while triangle gives
; it a restrained walking bass. Period bytes target NTSC APU timer values.
melody_lo:
        .byte $AB,$52,$1C,$D5, $52,$AB,$FD,$AB
        .byte $D5,$1C,$52,$AB, $1C,$D5,$AB,$FD
melody_hi:
        .byte $F9,$F9,$F9,$F8, $F9,$F9,$F8,$F9
        .byte $F8,$F9,$F9,$F9, $F9,$F8,$F9,$F8
bass_lo:
        .byte $52,$52,$52,$52, $AB,$AB,$AB,$AB
        .byte $1C,$1C,$1C,$1C, $AB,$AB,$AB,$AB
bass_hi:
        .byte $FA,$FA,$FA,$FA, $FA,$FA,$FA,$FA
        .byte $F9,$F9,$F9,$F9, $FA,$FA,$FA,$FA
step_frames:
        .byte 15,15,15,15, 15,15,15,15
        .byte 15,15,15,15, 15,15,15,30

.segment "BSS"
music_step:     .res 1
music_frames:   .res 1
music_enabled:  .res 1
pickup_phase:   .res 1
pickup_frames:  .res 1

.segment "CODE"
_music_start:
        lda #0
        sta music_enabled
        lda #$0F                    ; enable pulse 1/2, triangle, and noise
        sta APU_CHANCTRL
        lda #$BF                    ; 50% duty, constant volume 15
        sta APU_PULSE1CTRL
        lda #$00
        sta APU_PULSE1RAMP
        lda #$9A                    ; triangle counter runs continuously
        sta APU_TRICTRL1
        lda #$10                    ; silence effect channels without halting length counters
        sta APU_PULSE2CTRL
        sta APU_NOISECTRL
        lda #0
        sta music_step
        jsr music_load_step
        lda #1
        sta music_enabled
        rts

music_nmi_tick:
        jsr sfx_tick
        lda music_enabled
        beq music_done
        dec music_frames
        bne music_done
        inc music_step
        lda music_step
        cmp #MUSIC_STEPS
        bcc music_load_step
        lda #0
        sta music_step

music_load_step:
        ldx music_step
        lda step_frames,x
        sta music_frames
        lda melody_lo,x
        sta APU_PULSE1FTUNE
        lda melody_hi,x             ; writing high byte restarts its length
        sta APU_PULSE1CTUNE
        lda bass_lo,x
        sta APU_TRIFREQ1
        lda bass_hi,x
        sta APU_TRIFREQ2
music_done:
        rts

; Effects use pulse 2 or noise, never the title theme's pulse 1/triangle.
; The APU length counters end one-shot effects without a C-side frame timer.
_music_sfx_swing:
        lda #$9A                    ; hollow pulse, constant volume 10
        sta APU_PULSE2CTRL
        lda #$08                    ; gentle downward sweep
        sta APU_PULSE2RAMP
        lda #$E0
        sta APU_PULSE2FTUNE
        lda #$F8
        sta APU_PULSE2STUNE
        rts

_music_sfx_dialogue:
        lda #$96                    ; brief, soft acknowledgement blip
        sta APU_PULSE2CTRL
        lda #$00
        sta APU_PULSE2RAMP
        lda #$80
        sta APU_PULSE2FTUNE
        lda #$F8
        sta APU_PULSE2STUNE
        rts

_music_sfx_pickup:
        lda #0                      ; do not expose partially initialized state to NMI
        sta pickup_phase
        lda #5
        sta pickup_frames
        lda #$9F                    ; bright first half of the collection chime
        sta APU_PULSE2CTRL
        lda #$4A
        sta APU_PULSE2FTUNE
        lda #$F8
        sta APU_PULSE2STUNE
        lda #1
        sta pickup_phase
        rts

_music_sfx_hit:
        lda #$1F                    ; crisp noise hit, constant volume 15
        sta APU_NOISECTRL
        lda #$0B
        sta APU_NOISEFREQ1
        lda #$58                    ; 10 frames, then hardware silences it
        sta APU_NOISEFREQ2
        rts

_music_sfx_hurt:
        lda #$1C                    ; lower, longer noise thud for player damage
        sta APU_NOISECTRL
        lda #$05
        sta APU_NOISEFREQ1
        lda #$B9                    ; 22 frames, then hardware silences it
        sta APU_NOISEFREQ2
        rts

_music_sfx_door:
        lda #$18                    ; subdued doorway/room-transition knock
        sta APU_NOISECTRL
        lda #$03
        sta APU_NOISEFREQ1
        lda #$48                    ; 8 frames, then hardware silences it
        sta APU_NOISEFREQ2
        rts

; The pickup is the only effect needing a second timed note. NMI advances it
; even if collecting the item immediately begins a text-box redraw.
sfx_tick:
        lda pickup_phase
        beq sfx_done
        dec pickup_frames
        bne sfx_done
        lda #0
        sta pickup_phase
        lda #$9F
        sta APU_PULSE2CTRL
        lda #$1C                    ; higher second note: the audible "ding"
        sta APU_PULSE2FTUNE
        lda #$F8
        sta APU_PULSE2STUNE
sfx_done:
        rts
