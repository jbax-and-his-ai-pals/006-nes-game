; ------------------------------------------------------------------------
; portal.s -- town-portal entrance marker sprite tiles.
;
; Two tiles, both walk-onto-it landmarks that teleport the player (see
; main.c's Portal/portals[]), but shaped for two different contexts:
;
;   tile 0 - a standalone house, shaped like the same peak-roofed house
;            used for the town's own buildings (chr.s tile 5). Used for
;            the meadow's entrance into town, which sits alone in open
;            grass with no real house behind it, so it has to read as
;            "a house" entirely on its own.
;   tile 1 - a hollow doorway: a solid frame (same brown as the house
;            wall tiles) around a see-through center, plus a knob dot.
;            Used for the two actual house doors, which sit recessed
;            into a real house's bottom-left corner, surrounded by three
;            solid wall tiles of the exact same color -- tile 0's fully-
;            solid silhouette would be indistinguishable from those
;            neighbors there. The hollow center shows the floor tile
;            underneath through the doorway (the cell was carved out of
;            town_decorations for exactly this, so it's floor, not
;            another wall tile), which is what actually marks this one
;            cell as different at a glance instead of relying on color
;            alone.
;
; Same solid-color-index-1 encoding as the other actor tiles (plane0 =
; shape, plane1 = 0, except tile 1's knob dot which drops to index 2 for
; a dark accent -- same trick enemy.s/critter.s use for eyes) -- unlike
; chr.s tile 5, which is a *background* tile and uses plane1 for its
; color index (see that file's header), sprite tiles in this project all
; use plane0/index 1 as their base, with the sprite's own palette slot
; supplying the actual color.
;
; Linked after critter.s, so these land at
; PORTAL_TILE_BASE = CRITTER_TILE_BASE + 1 and
; PORTAL_DOOR_TILE_BASE = PORTAL_TILE_BASE + 1 (see main.c).
; ------------------------------------------------------------------------

.segment "CHARS"

; --- Tile 0: standalone house (meadow's entrance into town) ---
.byte $18, $3C, $7E, $FF, $FF, $E7, $E7, $FF    ; bit-plane 0 (house silhouette)
.repeat 8
        .byte $00
.endrepeat

; --- Tile 1: hollow doorway (the two houses' actual doors) ---
.byte $FF, $81, $81, $81, $81, $81, $81, $FF    ; bit-plane 0 (frame)
.byte $00, $00, $00, $00, $10, $00, $00, $00    ; bit-plane 1 (knob dot)
