; ------------------------------------------------------------------------
; house.s -- the town's house background tiles, roof-right and wall.
;
; A town house is a 2x2 cluster of decoration cells (see main.c's
; town_decorations), but unlike every other room's obstacle -- one tile
; repeated to form a bigger shape (tree.s's hedge, the boulder cluster,
; etc.) -- four copies of the same square just reads as four squares,
; not a house. So a house uses three *different* tiles instead, each
; drawn at a specific corner of its 2x2 footprint (main.c's
; chr_tile_for() picks which by exact (row, col), a town-specific case
; layered on top of room.c's normal per-room obstacle tile without room.c
; itself needing to know a house is anything special):
;
;   top-left     chr.s tile 5 (roof, left half)
;   top-right    this file, tile 0 (roof, right half)
;   bottom-left  no background tile at all -- it's ordinary floor, with
;                the door (a Portal sprite, portal.s) drawn over it, so
;                it can be walked onto instead of blocking like the
;                other three corners do
;   bottom-right this file, tile 1 (wall, with a small window)
;
; The two roof tiles are mirror images of each other, both plane1/color
; index 2 like every other obstacle tile in the game -- side by side
; they form one peaked roof instead of two separate triangles. The wall
; tile is otherwise fully solid (so it still butts seamlessly against
; whichever floor/path tiles surround the house) with a 2x2 window
; punched into it in index 0, echoing the door sprite's own hollow
; center rather than being a plain, featureless block.
;
; Linked immediately after chr.s, so these land at
; CHR_TILE_HOUSE_ROOF_R = CHR_TILE_HOUSE_ROOF_L + 1 and
; CHR_TILE_HOUSE_WALL = CHR_TILE_HOUSE_ROOF_R + 1 (see main.c).
; ------------------------------------------------------------------------

.segment "CHARS"

; --- Tile 0: roof, right half (mirror of chr.s tile 5) ---
.byte $00, $00, $00, $00, $00, $00, $00, $00    ; bit-plane 0
.byte $00, $80, $C0, $E0, $F0, $F8, $FC, $FE    ; bit-plane 1

; --- Tile 1: wall with a small window ---
.byte $00, $00, $00, $00, $00, $00, $00, $00    ; bit-plane 0
.byte $FF, $FF, $C3, $C3, $FF, $FF, $FF, $FF    ; bit-plane 1
