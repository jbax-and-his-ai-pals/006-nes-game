; ------------------------------------------------------------------------
; item.s -- fetch-quest item sprite tile.
;
; A small diamond/gem silhouette, distinct from both the player's solid
; block and the NPC's standing figure so a picked-up-able object reads
; as "a thing" at a glance. Same solid-color-index-1 encoding as the
; player/NPC tiles (plane0 = shape, plane1 = 0); its own sprite palette
; is what gives it a color distinct from both of them.
;
; Linked immediately after box_border.s, so this tile lands at
; ITEM_TILE_BASE = BORDER_TILE_BASE + 2 (see main.c).
; ------------------------------------------------------------------------

.segment "CHARS"

.byte %00011000   ; ...XX...
.byte %00111100   ; ..XXXX..
.byte %01111110   ; .XXXXXX.
.byte %11111111   ; XXXXXXXX
.byte %11111111   ; XXXXXXXX
.byte %01111110   ; .XXXXXX.
.byte %00111100   ; ..XXXX..
.byte %00011000   ; ...XX...
.repeat 8
        .byte $00
.endrepeat
