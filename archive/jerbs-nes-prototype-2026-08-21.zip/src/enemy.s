; ------------------------------------------------------------------------
; enemy.s -- combat enemy sprite tile.
;
; A simple rounded blob ("slime") -- distinct from the player's
; humanoid silhouette, the NPC's standing figure, and the item's
; diamond, so an enemy reads as a different kind of thing at a glance.
; Body is color index 1 (plane0 = shape, plane1 = 0), same as before,
; except for one row that drops in a pair of index-2 pixels as eyes --
; sprite palette 2's entry 2 already happens to be black (0x0F) in every
; room that has an enemy, so this needed no palette change to land as a
; believable pair of eye-dots instead of a blank color.
;
; Linked immediately after item.s, so this tile lands at
; ENEMY_TILE_BASE = ITEM_TILE_BASE + 1 (see main.c).
; ------------------------------------------------------------------------

.segment "CHARS"

.byte $3C, $7E, $DB, $FF, $FF, $FF, $7E, $3C    ; bit-plane 0
.byte $00, $00, $24, $00, $00, $00, $00, $00    ; bit-plane 1 (eye row)
