; ------------------------------------------------------------------------
; sword.s -- attack swing sprite tiles.
;
; Two tiles -- a vertical blade and a horizontal blade -- shown briefly
; at the attack point when the player swings (see main.c's ATTACK_MASK
; handling), oriented to match player_facing. NES background tiles can't
; rotate, but *sprites* can flip horizontally/vertically via OAM
; attribute bits, so one vertical tile covers both up (as-is) and down
; (V-flipped), and one horizontal tile covers both left (as-is) and
; right (H-flipped) -- 2 tiles instead of 4. Purely cosmetic, layered on
; top of the instant hit-check that already happens the same frame. Same
; solid-color-index-1 encoding as the other actor tiles (plane0 = shape,
; plane1 = 0).
;
; Linked immediately after enemy.s, so these land at
; SWORD_TILE_VERTICAL = ENEMY_TILE_BASE + 1 and
; SWORD_TILE_HORIZONTAL = ENEMY_TILE_BASE + 2 (see main.c).
; ------------------------------------------------------------------------

.segment "CHARS"

; --- Vertical blade: a straight blade with a crossguard partway down.
; Symmetric top-to-bottom on purpose, so V-flipping it for a downward
; swing still reads as the same sword, just pointing the other way. ---
.byte %00011000   ; ...XX...
.byte %00011000   ; ...XX...
.byte %00011000   ; ...XX...
.byte %00011000   ; ...XX...
.byte %00111100   ; ..XXXX..  crossguard
.byte %00011000   ; ...XX...
.byte %00011000   ; ...XX...
.byte %00011000   ; ...XX...
.repeat 8
        .byte $00
.endrepeat

; --- Horizontal blade: the vertical one rotated 90 degrees. ---
.byte %00000000
.byte %00000000
.byte %00011000
.byte %11111111
.byte %11111111
.byte %00011000
.byte %00000000
.byte %00000000
.repeat 8
        .byte $00
.endrepeat
