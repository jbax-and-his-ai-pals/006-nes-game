; ------------------------------------------------------------------------
; furniture.s -- house-interior furniture background tiles.
;
; Two tiles, both color index 1 (plane0 = shape, plane1 = 0) rather than
; index 2 like the wall tiles (CHR_TILE_TREE, reused for interior walls
; -- see main.c's room_obstacle_tile) -- that's what lets furniture read
; as a different *kind* of thing from the walls around it even though
; neither needed a new palette slot: index 1 is each house's own bg
; palette 0 entry 1 (the lighter wood-grain accent color already defined
; for every room, per room_palettes), index 2 is the darker wall brown.
;
;   tile 0 - table: a flat top on a narrow pedestal with a small base.
;   tile 1 - bed: a pillow block in one corner, blanket filling the rest.
;
; Linked after portal.s, so these land at
; FURNITURE_TABLE_TILE = PORTAL_DOOR_TILE_BASE + 1 and
; FURNITURE_BED_TILE = FURNITURE_TABLE_TILE + 1 (see main.c).
; ------------------------------------------------------------------------

.segment "CHARS"

; --- Tile 0: table ---
.byte $00, $7E, $7E, $18, $18, $3C, $00, $00    ; bit-plane 0
.repeat 8
        .byte $00
.endrepeat

; --- Tile 1: bed (pillow corner + blanket) ---
.byte $E0, $E0, $FF, $FF, $FF, $FF, $FF, $FF    ; bit-plane 0
.repeat 8
        .byte $00
.endrepeat
