; ------------------------------------------------------------------------
; critter.s -- ambient animal sprite tile (the town's wildlife).
;
; A small rounded bird/chicken silhouette -- distinct from the player's
; humanoid outline, the NPC's standing figure, the item's diamond, and
; the enemy's symmetric blob, so a critter reads as "harmless wildlife"
; rather than any of those at a glance. Body is color index 1 (plane0 =
; shape, plane1 = 0), with one row dropping in a single index-2 pixel
; for an eye, same trick enemy.s uses -- sprite palette 2's entry 2 is
; already black (0x0F) in every room, so this needed no palette change
; either.
;
; Linked after sword.s, so this tile lands at
; CRITTER_TILE_BASE = SWORD_TILE_HORIZONTAL + 1 (see main.c).
; ------------------------------------------------------------------------

.segment "CHARS"

.byte $20, $70, $B8, $FE, $FE, $7C, $28, $28    ; bit-plane 0
.byte $00, $00, $40, $00, $00, $00, $00, $00    ; bit-plane 1 (eye row)
