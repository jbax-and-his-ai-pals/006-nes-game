;
; startup.s -- project-owned cc65 NES startup.
;
; This is cc65's NES startup with one deliberate extension: every vblank
; NMI clocks the assembly music sequencer. Keeping the sequencer in assembly
; prevents an interrupt from re-entering cc65's non-reentrant C runtime.
;

        .export         _exit
        .export         __STARTUP__ : absolute = 1

        .import         initlib, donelib, callmain
        .import         zerobss, copydata
        .import         music_nmi_tick, _title_mouth_dirty, _title_mouth_open
        .import         _title_message_dirty, _title_message_index
        .import         title_message_0, title_message_1, title_message_2
        .import         __SRAM_START__, __SRAM_SIZE__
        .forceimport    NESfont

        .include        "zeropage.inc"
        .include        "nes.inc"

.segment "HEADER"
        .byte   $4e,$45,$53,$1a
        .byte   2               ; 2 x 16 KiB PRG-ROM banks
        .byte   1               ; 1 x 8 KiB CHR-ROM bank
        .byte   %00000011       ; horizontal mirroring, battery-backed RAM
        .byte   %00000000
        .byte   0,0,0,0,0,0,0,0

.segment "STARTUP"
start:
        sei
        cld
        ldx     #0
        stx     VBLANK_FLAG
        stx     ringread
        stx     ringwrite
        stx     ringcount
        txs

        lda     #$20
@clear_ring:
        sta     ringbuff,x
        sta     ringbuff+$0100,x
        sta     ringbuff+$0200,x
        inx
        bne     @clear_ring

        jsr     zerobss
        jsr     copydata

        lda     #<(__SRAM_START__ + __SRAM_SIZE__)
        ldx     #>(__SRAM_START__ + __SRAM_SIZE__)
        sta     c_sp
        stx     c_sp+1

        jsr     initlib
        jsr     callmain

_exit:  jsr     donelib
        jmp     start

; The NMI owns only timing and APU writes. Room/title rendering uses direct
; PPU register writes while forced blank, so touching PPU registers here
; could interrupt a multi-byte address/data sequence and corrupt the redraw.
nmi:    pha
        tya
        pha
        txa
        pha

        lda     #1
        sta     VBLANK_FLAG
        inc     tickcount
        bne     @tick_done
        inc     tickcount+1
@tick_done:
        jsr     music_nmi_tick
        jsr     title_message_nmi_tick
        jsr     title_mouth_nmi_tick

        pla
        tax
        pla
        tay
        pla
irq:    rti

; These tile IDs mirror main.c's title portrait layout: base tile 63, mouth
; source rows 7-9/columns 4-6, followed by the 3x3 closed-mouth patch.
title_mouth_open_tiles:
        .byte 137,138,139, 147,148,149, 157,158,159
title_mouth_closed_tiles:
        .byte 183,184,185, 186,187,188, 189,190,191

title_speech_plate:
        .byte 52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52
        .byte 53,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,53
        .byte 53,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,53
        .byte 53,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,53
        .byte 52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52,52

.macro WRITE_TITLE_MOUTH tiles
        lda     #$21                ; nametable row 15, column 6
        sta     PPU_VRAM_ADDR2
        lda     #$E6
        sta     PPU_VRAM_ADDR2
        lda     tiles+0
        sta     PPU_VRAM_IO
        lda     tiles+1
        sta     PPU_VRAM_IO
        lda     tiles+2
        sta     PPU_VRAM_IO

        lda     #$22                ; row 16, column 6
        sta     PPU_VRAM_ADDR2
        lda     #$06
        sta     PPU_VRAM_ADDR2
        lda     tiles+3
        sta     PPU_VRAM_IO
        lda     tiles+4
        sta     PPU_VRAM_IO
        lda     tiles+5
        sta     PPU_VRAM_IO

        lda     #$22                ; row 17, column 6
        sta     PPU_VRAM_ADDR2
        lda     #$26
        sta     PPU_VRAM_ADDR2
        lda     tiles+6
        sta     PPU_VRAM_IO
        lda     tiles+7
        sta     PPU_VRAM_IO
        lda     tiles+8
        sta     PPU_VRAM_IO
.endmacro

.macro WRITE_TITLE_MESSAGE tiles
        lda     #$21                ; nametable row 12, column 14
        sta     PPU_VRAM_ADDR2
        lda     #$8E
        sta     PPU_VRAM_ADDR2
        lda     tiles+0
        sta     PPU_VRAM_IO
        lda     tiles+1
        sta     PPU_VRAM_IO
        lda     tiles+2
        sta     PPU_VRAM_IO
        lda     tiles+3
        sta     PPU_VRAM_IO
        lda     tiles+4
        sta     PPU_VRAM_IO
        lda     tiles+5
        sta     PPU_VRAM_IO
        lda     tiles+6
        sta     PPU_VRAM_IO
        lda     tiles+7
        sta     PPU_VRAM_IO
        lda     tiles+8
        sta     PPU_VRAM_IO
        lda     tiles+9
        sta     PPU_VRAM_IO
        lda     tiles+10
        sta     PPU_VRAM_IO
        lda     tiles+11
        sta     PPU_VRAM_IO
        lda     tiles+12
        sta     PPU_VRAM_IO
        lda     tiles+13
        sta     PPU_VRAM_IO
        lda     tiles+14
        sta     PPU_VRAM_IO
        lda     tiles+15
        sta     PPU_VRAM_IO
        lda     tiles+16
        sta     PPU_VRAM_IO
.endmacro

.macro WRITE_SPEECH_ROW low, offset
        .local copy
        lda     #$21
        sta     PPU_VRAM_ADDR2
        lda     #low
        sta     PPU_VRAM_ADDR2
        ldx     #0
copy:
        lda     title_speech_plate+offset,x
        sta     PPU_VRAM_IO
        inx
        cpx     #19
        bne     copy
.endmacro

.macro CLEAR_SPEECH_ROW low
        .local clear
        lda     #$21
        sta     PPU_VRAM_ADDR2
        lda     #low
        sta     PPU_VRAM_ADDR2
        ldx     #19
        lda     #0
clear:
        sta     PPU_VRAM_IO
        dex
        bne     clear
.endmacro

.macro WRITE_SPEECH_ATTRIBUTES value
        .local upper, lower
        lda     #$23
        sta     PPU_VRAM_ADDR2
        lda     #$D3
        sta     PPU_VRAM_ADDR2
        ldx     #5
        lda     #value
upper:
        sta     PPU_VRAM_IO
        dex
        bne     upper
        lda     #$23
        sta     PPU_VRAM_ADDR2
        lda     #$DB
        sta     PPU_VRAM_ADDR2
        ldx     #5
        lda     #value
lower:
        sta     PPU_VRAM_IO
        dex
        bne     lower
.endmacro

; Draws the static plate tiles; the caller supplies the actual text row.
draw_title_speech_plate:
        WRITE_SPEECH_ROW $4D, 0
        WRITE_SPEECH_ROW $6D, 19
        WRITE_SPEECH_ROW $8D, 38
        WRITE_SPEECH_ROW $AD, 57
        WRITE_SPEECH_ROW $CD, 76
        rts

; Restores both the 19x5 plate and its one-tile shadow to the original title
; background. The five affected attribute bytes in rows 2 and 3 return to
; palette 0, which keeps the floor texture from inheriting plate colors.
clear_title_speech_plate:
        CLEAR_SPEECH_ROW $4D
        CLEAR_SPEECH_ROW $6D
        CLEAR_SPEECH_ROW $8D
        CLEAR_SPEECH_ROW $AD
        CLEAR_SPEECH_ROW $CD
        CLEAR_SPEECH_ROW $ED
        WRITE_SPEECH_ATTRIBUTES $00
        rts

; C queues only the line index; the NMI owns the complete PPU transaction.
title_message_nmi_tick:
        lda     _title_message_dirty
        bne     @queued
        rts
@queued:
        lda     #0
        sta     _title_message_dirty
        lda     PPU_STATUS
        lda     _title_message_index
        cmp     #3
        bne     :+
        jsr     clear_title_speech_plate
        lda     #0
        sta     PPU_VRAM_ADDR1
        sta     PPU_VRAM_ADDR1
        rts
:
        WRITE_SPEECH_ATTRIBUTES $55
        jsr     draw_title_speech_plate
        lda     _title_message_index
        bne     :+
        jmp     @line_0
:
        cmp     #1
        bne     :+
        jmp     @line_1
:
        jmp     @line_2
@line_0:
        WRITE_TITLE_MESSAGE title_message_0
        jmp     @restore_scroll
@line_1:
        WRITE_TITLE_MESSAGE title_message_1
        jmp     @restore_scroll
@line_2:
        WRITE_TITLE_MESSAGE title_message_2
@restore_scroll:
        lda     #0
        sta     PPU_VRAM_ADDR1
        sta     PPU_VRAM_ADDR1
        rts

; Applies a queued 3x3 title-mouth tile patch at the start of vblank. The
; frame data lives here, so the NMI never races C while reading nine bytes.
title_mouth_nmi_tick:
        lda     _title_mouth_dirty
        bne     @queued
        rts
@queued:
        lda     #0
        sta     _title_mouth_dirty

        lda     PPU_STATUS          ; reset the shared $2005/$2006 write latch
        lda     _title_mouth_open
        bne     @open
        jmp     @closed
@open:
        WRITE_TITLE_MOUTH title_mouth_open_tiles
        jmp     @restore_scroll
@closed:
        WRITE_TITLE_MOUTH title_mouth_closed_tiles

@restore_scroll:
        lda     #0                  ; restore the title's fixed scroll
        sta     PPU_VRAM_ADDR1
        sta     PPU_VRAM_ADDR1
@done:  rts

.segment "VECTORS"
        .word nmi
        .word start
        .word irq
