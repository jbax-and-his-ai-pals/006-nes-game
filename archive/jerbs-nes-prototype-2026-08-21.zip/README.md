# NES Game

An NES action-RPG in C, built incrementally. See [ROADMAP.md](ROADMAP.md)
for the design and the phased plan; this file just covers the mechanics
of building, running, and testing.

## How it's built

NES games are written for a 6502 CPU, so a normal PC compiler can't target
it. This project uses [cc65](https://cc65.github.io/), a C compiler suite
that targets 6502-based systems including the NES.

- `src/main.c` — game logic (C), using cc65's `<nes.h>` for direct PPU/
  controller register access.
- `src/movement.c` / `src/movement.h` — player movement and wall collision.
  Deliberately hardware-independent (no `<nes.h>`, no PPU/joypad access) so
  it can be unit-tested outside the NES target — see Testing below.
- `src/room.c` / `src/room.h` — room layout (borders, exits, decorations).
  Also hardware-independent and unit-tested.
- `src/font.c` / `src/font.h` — ASCII character to font-glyph-index
  mapping. Hardware-independent and unit-tested; the actual glyph bitmaps
  are CHR-ROM data (`src/font.s`), generated from readable ASCII-art
  glyph definitions by `tools/gen_font.py` rather than hand-written as hex.
- `src/text.c` / `src/text.h` — low-level nametable text/attribute-table
  drawing helpers (fill a row, draw a string, recolor an attribute row).
  Touches PPU hardware directly, so it isn't part of the tested set, but
  stays free of game-specific concepts so it's reusable.
- `src/chr.s` — CHR-ROM tile graphics (floor, obstacles, player, path).
  NES graphics are 2-bit-per-pixel tiles, not something a C compiler can
  express directly, so this piece is 6502 assembly (just data tables, no
  code logic).
- `assets/title_portrait_reference.png` / `tools/gen_title_portrait.py` —
  source art and reproducible four-color conversion for the title portrait;
  the generated NES tile data, including a nine-tile closed-mouth patch, lives
  in `src/title_portrait.s`.
- `assets/title_messages.txt` / `tools/gen_title_messages.py` — editable
  title-screen speech lines (up to 17 characters); `build.bat` regenerates their fixed-width NES
  font rows in `src/title_messages.s` automatically.
- `build.bat` — compiles everything into `game.nes`, an iNES-format ROM.
- `run.bat` — builds, then launches the ROM in Mesen.
- `test.bat` — runs the unit test suite (see below).

## Toolchain

- **cc65** is installed at `C:\tools\cc65` (built from source, since no
  prebuilt Windows binaries were reachable when this was set up — see
  below if you need to rebuild it).
- **Mesen 2** (NES emulator) was installed via `winget install --id
  SourMesen.Mesen2`.

## Building

```
build.bat
```

Produces `game.nes` in this folder.

## Running

```
run.bat
```

Or open `game.nes` directly in any NES emulator (Mesen 2, FCEUX, etc.).
Release A/Start, then press either one on the title screen to begin a new
game. Its looping pulse-and-triangle theme continues into gameplay at a
vblank-locked tempo. Sword swings, dialogue, pickups, combat, damage, and
doorways each have their own NES-style sound effect. The `HP 10` readout is
at the upper left. Use the D-pad (arrow keys, in most keyboard mappings) to
move, `A` to talk/select, `B` to swing or dismiss the pause menu, and `Start`
to open the menu. The menu's Inventory action lists collected quest items;
Quit returns to a fresh New Game title flow.

## Testing

```
test.bat
```

cc65 ships `sim65`, a headless 6502 simulator, plus a `sim6502` build
target with standard C library support (`printf`, etc.). That's enough to
unit-test any *hardware-independent* logic — no emulator GUI, no manual
key presses, real pass/fail exit codes.

- `tests/test_movement.c` compiles and tests the real `src/movement.c`
  directly (bounds clamping, wall alignment, diagonal input).
- `tests/test_read_pad.c` tests the controller bit-assembly algorithm
  from `main.c`'s `read_pad()` against a mocked shift register. It can't
  compile the real function (that one touches actual NES hardware at
  `$4016`, which doesn't exist under `sim65`), so it mirrors the
  algorithm instead — keep the two in sync by hand if it ever changes.

**What this doesn't cover:** anything that depends on real PPU/vblank
timing (OAM updates, nametable writes, rendering) can't be unit-tested
this way — `sim65` has no PPU. That category stays manually verified in
an emulator. This is exactly the split that mattered in practice: the
first real bug this project shipped (sprite appearing frozen) was a
vblank-timing issue that no amount of logic-level testing would have
caught, while the second (wall-alignment math) was exactly the kind of
thing `test_movement.c` now catches automatically.

As new hardware-independent systems get added (quest generation, NPC
schedules, etc.), they should follow `movement.c`'s pattern: no `<nes.h>`,
no direct register access, and a test file alongside them.

**A pitfall when manually verifying in Mesen:** a freshly-launched Mesen
window doesn't necessarily show a real, computed frame right away —
sometimes it sits on a blank/backdrop-colored screen for several seconds
before it starts painting actual output, with no error, dialog, or other
indication anything is wrong. Screenshotting too early looks exactly like
a hung or crashed ROM. This cost a lot of debugging time once (chasing a
ROM "crash" that only reproduced with a large decoration list) before
turning out to be nothing but this — the exact same ROM rendered
correctly given a longer wait, with zero code changes. If a room looks
blank in a screenshot, wait several seconds and check again before
suspecting the code.

**A second pitfall, same root cause:** the visible Mesen window in this
environment often doesn't show the game's full 256px width — screenshots
can be missing the left edge of the room. A test message rendered as
"MEADOW" showed only as "DOW" in one screenshot; a later, unrelated test
string ("HI THERE") showed only as "HERE" — both times exactly the
trailing substring, at a consistent crop point across different window
sizes/positions. That consistency (not a ragged, position-dependent cut)
is the tell that it's a display/screenshot crop, not a rendering bug —
confirmed by testing the underlying string/centering arithmetic directly
under `sim65` (no PPU, no screenshot involved), which came back exactly
as expected. When a screenshot looks truncated, checking the pure logic
in isolation (if it's hardware-independent) is much faster and more
reliable than trying to recalibrate window/scale assumptions from
screenshot pixels again.

**A real hardware bug, not a tooling one: always reset OAMADDR ($2003)
to 0 after writing OAM each frame.** Adding a second on-screen sprite
(an NPC) made it never render at all -- not a wrong position, not a
wrong color, just absent, regardless of what tile/palette/coordinates it
was given. The cause: every OAM write (`$2003` then four `$2004`s) left
`$2003` sitting at whatever address the write ended on. `$2003` isn't
just a write cursor -- the PPU also uses it as its own internal read
pointer during each scanline's sprite evaluation, so leaving it non-zero
at the end of vblank corrupts that evaluation for the *entire next
frame*, not just whatever sprite was written last. Confirmed by writing
a hardcoded, always-drawn debug sprite directly to the same OAM slot
(bypassing all app logic) and watching it also fail to appear, then
watching it appear the instant an explicit `PPU.sprite.address = 0`
followed the writes. Fixed once, at the source (`set_oam_sprite()`/
`hide_oam_sprite()` in `main.c`), rather than trusting every call site to
remember it.

**A follow-up hardware lesson, same neighborhood: manual per-sprite OAM
writes don't just risk the bug above -- their cost scales with entity
count.** After the OAMADDR fix, sprites still stopped rendering again
once the frame had enough of them (player + several NPCs + an enemy +
an attack-swing sprite): the later writes in that sequence were landing
after vblank ended and getting silently dropped by the PPU, confirmed
the same way as the OAMADDR bug -- a debug sprite write at the very
front of the frame rendered, the identical write in its normal spot
later in the sequence didn't. Reordering the writes would only have
deferred the same failure to the next sprite added. The real fix is the
standard NES technique for exactly this: maintain a full shadow OAM
buffer in RAM and copy the whole thing to the PPU in one hardware DMA
transfer (`$4014`) each frame -- a fixed 513-514 CPU cycles no matter
how many sprites are in use, instead of a cost that grows with the
entity roster. Worth knowing before writing OAM updates by hand on this
project again: past a couple of sprites, don't -- use the DMA path
(`oam_buf`/`oam_flush()` in `main.c`) instead of adding more manual
`$2003`/`$2004` writes to the pile.

## Rebuilding cc65 from source (if `C:\tools\cc65` is ever missing)

cc65's Windows snapshot builds are hosted on SourceForge behind a
Cloudflare bot check that blocks non-browser downloads, so the toolchain
here was compiled from source instead:

```
winget install --id BrechtSanders.WinLibs.POSIX.UCRT -e   # gcc + make
git clone --depth 1 https://github.com/cc65/cc65.git
cd cc65
mingw32-make -j4
```

Then copy `bin/`, `cfg/`, `include/`, `asminc/`, and `lib/nes.lib` plus
`lib/sim6502.lib` (needed for `test.bat`) to `C:\tools\cc65` (the full
`lib/` folder is ~65MB since it holds libraries for every 6502 system
cc65 supports; only those two are needed here).
