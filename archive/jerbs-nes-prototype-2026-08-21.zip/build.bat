@echo off
setlocal

set CC65_HOME=C:\tools\cc65
set PATH=%CC65_HOME%\bin;%PATH%

python tools\gen_title_messages.py
if errorlevel 1 (
    echo.
    echo Title-message generation FAILED.
    exit /b 1
)

cl65 -t nes -o game.nes src\startup.s src\music.s src\chr.s src\house.s src\font.s src\npc.s src\box_border.s src\item.s src\enemy.s src\sword.s src\critter.s src\portal.s src\furniture.s src\title_portrait.s src\title_messages.s src\main.c src\movement.c src\room.c src\text.c src\font.c src\rng.c src\quest.c src\world.c
if errorlevel 1 (
    echo.
    echo Build FAILED.
    exit /b 1
)

echo.
echo Build OK: game.nes
endlocal
